# DSV4L2 AI Documentation Bundle

**Comprehensive reference package for AI assistants and developers**

Version: 1.0
Date: 2025-11-25
Project: DSV4L2 - DSLLVM-Enhanced Video4Linux2 Sensor Stack

---

## What This Bundle Contains

This package contains complete documentation for the DSV4L2 project - a DSLLVM-instrumented sensor front-end that transforms v4l2ctl from a simple camera library into a security-aware, policy-enforced, telemetry-enabled sensor node in the DSMIL (Defense System Multi-layer Integration Layer) fabric.

### Purpose

DSV4L2 provides:
- **Role-aware sensor classification**: Cameras, iris scanners, IR sensors, TEMPEST devices
- **Security enforcement at compile-time**: Secret flow tracking, TEMPEST policy, constant-time operations
- **Runtime telemetry**: Event-based monitoring integrated with DSMIL fabric
- **Quantum optimization hooks**: Candidate tagging for L7/L8 offload
- **Military-grade stream handling**: KLV metadata, radiometric decoding, fused capture

---

## Bundle Structure

```
dsv4l2_ai_bundle/
├── README.md                           # This file
├── QUICK_START.md                      # Fast track to using DSV4L2
│
├── docs/
│   ├── 00_OVERVIEW.md                  # High-level architecture summary
│   ├── 01_DESIGN.md                    # Complete design document
│   ├── 02_DSLLVM_CONTEXT.md           # DSLLVM compiler overview
│   ├── 03_INSTRUMENTATION.md          # Runtime telemetry specification
│   ├── 04_SECURITY_MODEL.md           # Security enforcement details
│   └── 05_INTEGRATION_GUIDE.md        # How to integrate with DSMIL
│
├── headers/
│   ├── dsv4l2_annotations.h           # DSLLVM attribute macros & types
│   ├── dsv4l2_policy.h                # Policy API declarations
│   └── dsv4l2rt.h                     # Runtime instrumentation API
│
├── config/
│   └── dsllvm_dsv4l2_passes.yaml      # DSLLVM pass configuration
│
├── examples/
│   ├── instrumented_capture_example.c  # Before/after code examples
│   └── profile_iris_scanner.yaml      # Example device profile
│
└── reference/
    ├── ORIGINAL_BUNDLE_README.md      # Original zip bundle documentation
    ├── V4L2CTL_ORIGINAL_README.rst    # Original v4l2ctl project readme
    └── COMPILER_FLAGS.md              # Complete DSLLVM flag reference
```

---

## Key Concepts

### 1. DSLLVM (Defense System LLVM)

A specialized LLVM compiler with optional security and telemetry extensions:
- Tracks upstream LLVM closely (minimal invasiveness)
- Adds DSMIL integration, AI/telemetry hooks, quantum-aware design
- Enforces security policies at IR level via custom passes

### 2. DSMIL (Defense System Multi-layer Integration Layer)

An 8-layer architecture (L0-L8) for defense systems:
- DSV4L2 operates at **L3** (sensor/device layer)
- Provides typed, annotated sensor signals to upper layers
- Enforces layer-specific security policies

### 3. TEMPEST State Machine

Electromagnetic security primitive:
- 4 states: DISABLED, LOW, HIGH, LOCKDOWN
- DSLLVM enforces state checks before capture operations
- State transitions are logged and policy-checked

### 4. Secret Flow Tracking

Compile-time enforcement preventing data leaks:
- Biometric frames tagged as `dsmil_secret`
- DSLLVM forbids logging, network egress, unencrypted storage
- Only allowed sinks: encrypted storage, secure links, explicit declassify

### 5. Instrumentation Profiles

Runtime telemetry controlled by compile flags:
- `off`: No runtime probes, only static metadata
- `ops`: Minimal counters (frames, errors, TEMPEST transitions)
- `exercise`: Per-stream stats, metadata sampling
- `forensic`: Maximal logging (within policy), full audit trail

---

## How to Use This Bundle

### For AI Assistants

1. Start with `docs/00_OVERVIEW.md` for context
2. Read `QUICK_START.md` for common tasks
3. Reference `docs/01_DESIGN.md` for complete architecture
4. Use `headers/*.h` for API reference
5. Study `examples/instrumented_capture_example.c` for code patterns

### For Developers

1. Read `QUICK_START.md` to get oriented
2. Review `docs/02_DSLLVM_CONTEXT.md` to understand the compiler
3. Study `docs/03_INSTRUMENTATION.md` for runtime integration
4. Check `docs/05_INTEGRATION_GUIDE.md` for DSMIL fabric connection
5. Use example code as templates for your implementations

### For Security Reviewers

1. Start with `docs/04_SECURITY_MODEL.md`
2. Review `config/dsllvm_dsv4l2_passes.yaml` for enforcement rules
3. Study secret flow tracking and TEMPEST policy in `docs/01_DESIGN.md`
4. Examine `headers/dsv4l2_annotations.h` for security attributes
5. Check `examples/` for proper annotation usage

---

## Build Quick Reference

### Standard Build (Plain GCC/Clang)

```bash
# Install dependencies
apt-get install libv4l-dev cython

# Build
python3 setup.py build
python3 setup.py install
```

### DSLLVM Build (Instrumented)

```bash
dsclang -O2 \
  -fplugin=libDSLLVM.so \
  -fplugin-arg-dsllvm-pass-config=config/dsllvm_dsv4l2_passes.yaml \
  -fdsv4l2-profile=ops \
  -mdsv4l2-mission=operation_name \
  -I include \
  -c dsv4l2_core.c -o dsv4l2_core.o

# Link with runtime
gcc dsv4l2_core.o -ldsv4l2rt -lv4l2 -o dsv4l2
```

---

## Key Files Reference

| File | Purpose | AI Priority |
|------|---------|-------------|
| `docs/01_DESIGN.md` | Complete architecture | **CRITICAL** |
| `headers/dsv4l2_annotations.h` | Attribute definitions | **CRITICAL** |
| `config/dsllvm_dsv4l2_passes.yaml` | Security enforcement config | **CRITICAL** |
| `examples/instrumented_capture_example.c` | Code patterns | **HIGH** |
| `docs/02_DSLLVM_CONTEXT.md` | Compiler understanding | **HIGH** |
| `docs/03_INSTRUMENTATION.md` | Runtime spec | **MEDIUM** |
| `QUICK_START.md` | Fast reference | **MEDIUM** |

---

## Implementation Status

### ✅ Completed (Phase 1)
- DSLLVM bundle extraction
- Core headers (annotations, policy, runtime)
- Pass configuration
- Instrumented examples
- Comprehensive documentation

### 🚧 In Progress
- None currently

### 📋 TODO (Phases 2-8)
- Core library implementation (`libdsv4l2_core`)
- Profile system (`libdsv4l2_profiles`)
- Policy layer (`libdsv4l2_policy`)
- Metadata/fusion (`libdsv4l2_meta`)
- Runtime implementation (`libdsv4l2rt`)
- CLI tool (`dsv4l2_cli`)
- Testing & validation

See `docs/01_DESIGN.md` Section 12 for complete roadmap.

---

## Pattern Recognition for AI

This project follows the **SHRINK pattern** for DSLLVM instrumentation:

1. **Compiler flags** control instrumentation verbosity
2. **Source attributes** mark functions, data, events with semantic metadata
3. **DSLLVM passes** enforce policies and auto-inject runtime probes
4. **Tiny runtime** buffers events and ships to DSMIL fabric

When implementing similar systems (audio, network, storage), replicate:
- The annotation structure (`include/dsv4l2_annotations.h`)
- The pass configuration pattern (`config/dsllvm_dsv4l2_passes.yaml`)
- The runtime API design (`include/dsv4l2rt.h`)
- The instrumentation example structure (`examples/`)

---

## Related Systems

- **SHRINK**: Operator action telemetry (same instrumentation pattern)
- **MEMSHADOW**: Long-term behavioral memory
- **SPECTRA**: AI orchestration layer (L8)
- **DSMIL**: Multi-layer integration fabric
- **DSLLVM**: Security-aware compiler infrastructure

---

## Contact & Attribution

**Project**: SWORDIntel/v4l2ctl
**Branch**: claude/extract-zip-file-015jv6wv3r1wDwzqA9bL52MG
**Base**: pyv4l2 by pupil-labs (https://github.com/pupil-labs/pyv4l2)

**License**: See LICENSE file in repository

---

## Version History

- **1.0** (2025-11-25): Initial bundle creation
  - Extracted DSLLVM integration files
  - Created instrumentation layer
  - Comprehensive documentation
  - AI-ready reference structure

---

**This bundle is optimized for AI consumption. All files use clear structure, comprehensive comments, and consistent patterns for easy parsing and understanding.**
