# DSLLVM Compiler Flags Reference for DSV4L2

**Complete flag documentation for compiling DSV4L2 code**

---

## Core DSLLVM Flags

### `-fplugin=libDSLLVM.so`

**Purpose**: Load the DSLLVM plugin into clang

**Required**: Yes (for any DSLLVM features)

**Example**:
```bash
dsclang -fplugin=/path/to/libDSLLVM.so my_sensor.c
```

---

### `-fplugin-arg-dsllvm-pass-config=<file>`

**Purpose**: Specify DSLLVM pass configuration file

**Required**: Yes (for security enforcement)

**Value**: Path to YAML configuration file

**Example**:
```bash
dsclang -fplugin=libDSLLVM.so \
  -fplugin-arg-dsllvm-pass-config=config/dsllvm_dsv4l2_passes.yaml \
  my_sensor.c
```

**What it does**:
- Loads pass definitions (secret_flow, tempest_policy, constant_time)
- Configures enforcement rules
- Sets allowed/forbidden operations

---

## DSV4L2-Specific Flags

### `-fdsv4l2-profile=<level>`

**Purpose**: Control instrumentation verbosity

**Required**: No (default: `off`)

**Values**:
- `off` - No runtime instrumentation, only static metadata
- `ops` - Minimal counters (frames captured, errors, TEMPEST transitions)
- `exercise` - Per-stream stats, metadata sampling, performance metrics
- `forensic` - Maximal logging (every event, full context, TPM-signed)

**Example**:
```bash
# Production deployment (minimal overhead)
dsclang -fdsv4l2-profile=ops my_sensor.c

# Testing/validation (detailed metrics)
dsclang -fdsv4l2-profile=exercise my_sensor.c

# Incident response (full audit trail)
dsclang -fdsv4l2-profile=forensic my_sensor.c
```

**Impact on binary**:
- `off`: No runtime calls injected, smallest binary
- `ops`: Lightweight calls at major events (~5% overhead)
- `exercise`: Moderate instrumentation (~15% overhead)
- `forensic`: Heavy instrumentation (~30% overhead, TPM operations)

---

### `-fdsv4l2-metadata`

**Purpose**: Emit only static metadata, no runtime instrumentation

**Required**: No

**Use case**: Offline analysis, deployment planning, L8 advisor input

**Example**:
```bash
dsclang -fdsv4l2-metadata my_sensor.c
```

**Output**: ELF sections with sensor metadata (roles, layers, classifications)

**Can combine with**: None (mutually exclusive with `-fdsv4l2-profile`)

---

### `-mdsv4l2-mission=<name>`

**Purpose**: Tag binaries with mission/operation context

**Required**: No

**Value**: Mission identifier (alphanumeric, underscores allowed)

**Example**:
```bash
dsclang -mdsv4l2-mission=operation_red_dawn my_sensor.c
```

**What it does**:
- Adds mission tag to static metadata
- Included in runtime events (for correlation)
- Used by MEMSHADOW for long-term context

**Appears in**: Event telemetry, ELF metadata, SARIF logs

---

## Standard Clang Flags (Commonly Used)

### `-O2` / `-O3`

**Purpose**: Optimization level

**Recommended**: `-O2` for production, `-O3` for performance-critical

**Example**:
```bash
dsclang -O2 -fdsv4l2-profile=ops my_sensor.c
```

**Note**: DSLLVM passes run after optimization (post-inlining)

---

### `-I <path>`

**Purpose**: Include directory for headers

**Required**: Yes (for DSV4L2 headers)

**Example**:
```bash
dsclang -I include -I /usr/include/libv4l2 my_sensor.c
```

---

### `-L <path>` / `-l<lib>`

**Purpose**: Link with libraries

**Required**: Yes (for v4l2, dsv4l2rt)

**Example**:
```bash
dsclang my_sensor.o -L/usr/local/lib -ldsv4l2rt -lv4l2 -o my_sensor
```

---

### `-g`

**Purpose**: Include debug symbols

**Recommended**: Yes (for development)

**Example**:
```bash
dsclang -g -O2 -fdsv4l2-profile=exercise my_sensor.c
```

**Note**: DSLLVM preserves debug info through passes

---

## Flag Combinations

### Development Build

```bash
dsclang -g -O0 \
  -fplugin=libDSLLVM.so \
  -fplugin-arg-dsllvm-pass-config=config/dsllvm_dsv4l2_passes.yaml \
  -fdsv4l2-profile=exercise \
  -mdsv4l2-mission=dev_test \
  -I include \
  my_sensor.c -o my_sensor
```

**Characteristics**:
- Debug symbols included
- No optimization (easier debugging)
- Exercise-level instrumentation
- Tagged as dev_test mission

---

### Production Build

```bash
dsclang -O2 \
  -fplugin=libDSLLVM.so \
  -fplugin-arg-dsllvm-pass-config=config/dsllvm_dsv4l2_passes.yaml \
  -fdsv4l2-profile=ops \
  -mdsv4l2-mission=operation_name \
  -I include \
  my_sensor.c -o my_sensor
```

**Characteristics**:
- Optimized (-O2)
- Minimal instrumentation (ops)
- Mission-tagged
- Security enforcement enabled

---

### Forensic Build

```bash
dsclang -O2 -g \
  -fplugin=libDSLLVM.so \
  -fplugin-arg-dsllvm-pass-config=config/dsllvm_dsv4l2_passes.yaml \
  -fdsv4l2-profile=forensic \
  -mdsv4l2-mission=incident_response \
  -I include \
  my_sensor.c -o my_sensor
```

**Characteristics**:
- Optimized but with debug symbols
- Maximal instrumentation
- TPM-signed event chunks
- Full audit trail

---

### Metadata-Only Build

```bash
dsclang -O2 \
  -fplugin=libDSLLVM.so \
  -fplugin-arg-dsllvm-pass-config=config/dsllvm_dsv4l2_passes.yaml \
  -fdsv4l2-metadata \
  -I include \
  my_sensor.c -o my_sensor
```

**Characteristics**:
- No runtime overhead
- Static metadata only
- For offline analysis
- No libdsv4l2rt dependency

---

## Flag Interactions

### Conflicting Flags

**Cannot use together**:
- `-fdsv4l2-profile=<level>` and `-fdsv4l2-metadata`
  (Choose either runtime instrumentation OR metadata-only)

---

### Implied Dependencies

**If using `-fdsv4l2-profile=<level>`**:
- Must link with `-ldsv4l2rt`
- Runtime must be initialized (`dsv4l2rt_init()`)
- Sink configuration required (Redis, SQLite, etc.)

**If using `-fdsv4l2-profile=forensic`**:
- Must have TPM2 support
- Must link with `-ltss2-esys`
- Runtime config must enable TPM signing

---

## Environment Variables

### `DSLLVM_PLUGIN_PATH`

**Purpose**: Default path to libDSLLVM.so

**Example**:
```bash
export DSLLVM_PLUGIN_PATH=/usr/local/lib/libDSLLVM.so
dsclang -fplugin=$DSLLVM_PLUGIN_PATH my_sensor.c
```

---

### `DSV4L2_CONFIG_PATH`

**Purpose**: Default path to pass configuration

**Example**:
```bash
export DSV4L2_CONFIG_PATH=/etc/dsv4l2/passes.yaml
dsclang -fplugin-arg-dsllvm-pass-config=$DSV4L2_CONFIG_PATH my_sensor.c
```

---

## Build System Integration

### Makefile Example

```makefile
CC = dsclang
CFLAGS = -O2 -g -I include
DSLLVM_FLAGS = -fplugin=libDSLLVM.so \
               -fplugin-arg-dsllvm-pass-config=config/dsllvm_dsv4l2_passes.yaml \
               -fdsv4l2-profile=ops \
               -mdsv4l2-mission=$(MISSION)
LDFLAGS = -ldsv4l2rt -lv4l2

my_sensor: my_sensor.o
	$(CC) $< $(LDFLAGS) -o $@

my_sensor.o: my_sensor.c
	$(CC) $(CFLAGS) $(DSLLVM_FLAGS) -c $< -o $@
```

---

### CMake Example

```cmake
set(CMAKE_C_COMPILER "dsclang")

set(DSLLVM_FLAGS
    "-fplugin=libDSLLVM.so"
    "-fplugin-arg-dsllvm-pass-config=${CMAKE_SOURCE_DIR}/config/dsllvm_dsv4l2_passes.yaml"
    "-fdsv4l2-profile=ops"
    "-mdsv4l2-mission=${MISSION_NAME}"
)

add_compile_options(${DSLLVM_FLAGS})
target_link_libraries(my_sensor dsv4l2rt v4l2)
```

---

## Debugging Flags

### `-fdsllvm-debug`

**Purpose**: Enable DSLLVM pass debugging output

**Example**:
```bash
dsclang -fdsllvm-debug -fplugin=libDSLLVM.so my_sensor.c
```

**Output**: Pass execution logs, annotation discovery, policy checks

---

### `-fdsllvm-dump-ir`

**Purpose**: Dump LLVM IR after each pass

**Example**:
```bash
dsclang -fdsllvm-dump-ir -fplugin=libDSLLVM.so my_sensor.c
```

**Output**: `.ll` files showing IR transformations

---

## Quick Reference Table

| Flag | Purpose | Required | Default | Values |
|------|---------|----------|---------|--------|
| `-fplugin=libDSLLVM.so` | Load DSLLVM | Yes* | N/A | Path to .so |
| `-fplugin-arg-dsllvm-pass-config=<file>` | Pass config | Yes* | N/A | Path to .yaml |
| `-fdsv4l2-profile=<level>` | Instrumentation | No | `off` | off/ops/exercise/forensic |
| `-fdsv4l2-metadata` | Static metadata | No | Disabled | (flag only) |
| `-mdsv4l2-mission=<name>` | Mission tag | No | None | String |
| `-O2` | Optimization | No | `-O0` | 0/1/2/3/s |
| `-g` | Debug symbols | No | Disabled | (flag only) |
| `-I <path>` | Include path | Yes** | N/A | Directory |
| `-L <path>` | Library path | No | System | Directory |
| `-l<lib>` | Link library | Yes*** | N/A | Library name |

\* Required for DSLLVM features
\** Required for DSV4L2 headers
\*** Required for libdsv4l2rt (if using instrumentation)

---

## Common Errors

### Error: "plugin 'DSLLVM' not found"

**Cause**: Plugin path incorrect or DSLLVM not built

**Fix**: Check path to `libDSLLVM.so`, verify DSLLVM build

---

### Error: "pass configuration file not found"

**Cause**: Config file path incorrect

**Fix**: Use absolute path or verify relative path from build directory

---

### Error: "undefined reference to 'dsv4l2rt_emit'"

**Cause**: Using `-fdsv4l2-profile=<level>` but not linking with runtime

**Fix**: Add `-ldsv4l2rt` to linker flags

---

### Warning: "unknown dsv4l2 profile level"

**Cause**: Typo in profile level (e.g., `Op` instead of `ops`)

**Fix**: Use lowercase: `off`, `ops`, `exercise`, `forensic`

---

## Best Practices

1. **Always use `-O2` or higher** in production (DSLLVM passes benefit from optimization)
2. **Include debug symbols** (`-g`) even in optimized builds (for forensic analysis)
3. **Tag with mission** (`-mdsv4l2-mission=`) for operational correlation
4. **Start with `ops` profile** for new deployments (low overhead)
5. **Use `exercise` for testing** (good balance of detail and performance)
6. **Reserve `forensic` for incidents** (high overhead, TPM required)
7. **Verify pass config** with a test build before production

---

**This reference covers all flags specific to DSV4L2 compilation with DSLLVM.**
