# DSLLVM Compiler Context

**Understanding the compiler that makes DSV4L2 possible**

Based on: https://github.com/SWORDIntel/DSLLVM

---

## What is DSLLVM?

DSLLVM (Defense System LLVM Compiler) is a specialized build of the LLVM compiler infrastructure designed for defense and security-critical systems.

**Version**: 1.6.0 (Phase 3: High-Assurance)

**Key principle**: "Minimally invasive extension layer on top of LLVM/Clang/LLD"

---

## Core Characteristics

### 1. Tracks Upstream LLVM Closely

- Uses standard LLVM passes and IR semantics
- Core compiler behavior unchanged
- Drop-in replacement for clang/lld for normal code
- 560,555+ commits tracking upstream

### 2. Optional Integration Points

- **Not mandatory**: Code compiles without DSLLVM-specific features
- **Opt-in**: Use flags and attributes to enable features
- **Graceful degradation**: Attributes become no-ops on standard compilers

### 3. Four Key Capabilities

#### A. DSMIL Integration
- Lightweight annotations for device/layer routing
- Clearance tags and audit metadata
- All integration points are opt-in

#### B. AI & Telemetry Hooks
- Embeds feature metadata in build artifacts
- Performance profiles, security markers, deployment hints
- Emits signals for higher-layer systems to consume

#### C. Quantum-Aware Design
- Attaches "quantum candidate" hints to optimization problems
- Preserves hints in IR/object metadata
- External Qiskit pipelines can consume hints
- Does not execute quantum workloads internally

#### D. Post-Quantum Cryptography Alignment
- Compatible with CNSA 2.0 suites:
  - ML-KEM-1024 (key encapsulation)
  - ML-DSA-87 (digital signatures)
  - SHA-384 (hashing)
- Does not ship cryptography itself
- Exposes configuration knobs for downstream enforcement

---

## How DSV4L2 Uses DSLLVM

### 1. Source-Level Annotations

We define attributes that DSLLVM understands:

```c
// From dsv4l2_annotations.h
#define DSMIL_SECRET(tag) __attribute__((dsmil_secret(tag)))
#define DSMIL_TEMPEST __attribute__((dsmil_tempest))
#define DSV4L2_SENSOR(role, layer, classification) \
    __attribute__((dsv4l2_sensor(role, layer, classification)))
```

**On standard compilers**: These expand to nothing via `DSMIL_ATTR(x)`

**On DSLLVM**: These trigger custom passes

---

### 2. Custom DSLLVM Passes

Configured in `config/dsllvm_dsv4l2_passes.yaml`:

#### Pass 1: Secret Flow Checker (`dsmil.secret_flow`)

**What it does**:
- Tracks data tagged with `dsmil_secret(tag)` across LLVM IR
- Verifies only allowed sinks are used
- Rejects builds with violations

**Example enforcement**:
```c
// This FAILS to compile:
dsv4l2_frame_t *iris = ...; // Tagged dsmil_secret("biometric_frame")
printf("%p\n", iris->data);  // ERROR: Forbidden sink 'printf'

// This SUCCEEDS:
dsv4l2_store_encrypted(iris); // Allowed sink
```

**Configuration** (lines 24-66 of YAML):
- `classify`: Which types/functions produce secrets
- `allowed_sinks`: Where secrets can go (encrypted storage, secure network)
- `forbidden_apis`: What can't touch secrets (printf, send, write, etc.)

---

#### Pass 2: TEMPEST Policy (`dsmil.tempest_policy`)

**What it does**:
- Tracks TEMPEST state enum across IR
- Ensures functions marked `dsmil_requires_tempest_check` actually check state
- Verifies policy check happens before capture

**Example enforcement**:
```c
// This FAILS to compile:
int dsv4l2_capture_frame(dsv4l2_device_t *dev, dsv4l2_frame_t *out)
    __attribute__((dsmil_requires_tempest_check))
{
    // ERROR: No tempest check found in function
    return capture_internal(dev, out);
}

// This SUCCEEDS:
int dsv4l2_capture_frame(dsv4l2_device_t *dev, dsv4l2_frame_t *out)
    __attribute__((dsmil_requires_tempest_check))
{
    dsv4l2_tempest_state_t state = dsv4l2_get_tempest_state(dev);
    if (dsv4l2_policy_check(state, "capture") != 0) return -EPERM;
    return capture_internal(dev, out);
}
```

**Configuration** (lines 68-97 of YAML):
- `symbols`: Which functions query/transition state
- `policies`: What transitions are allowed
- `forbid_states_on_output`: States that block capture (LOCKDOWN)

---

#### Pass 3: Constant-Time Guard (`dsmil.constant_time`)

**What it does**:
- Enforces timing-safe operations in `dsmil_secret_region`
- Forbids secret-dependent branches, switches, array indexing
- Prevents timing side-channels

**Example enforcement**:
```c
// This FAILS to compile:
__attribute__((dsmil_secret_region))
void process_iris(uint8_t *iris_data) {
    if (iris_data[0] > 128) {  // ERROR: Branch on secret
        enhance();
    }
}

// This SUCCEEDS:
__attribute__((dsmil_secret_region))
void process_iris(uint8_t *iris_data) {
    int mask = -(iris_data[0] > 128);  // Branchless
    enhance_masked(mask);
}
```

**Configuration** (lines 99-123 of YAML):
- `scope`: Which functions are checked
- `rules`: What operations are forbidden
- `exceptions`: Allowed patterns (e.g., memcpy)

---

### 3. Instrumentation Injection

**Controlled by compiler flags**:

```bash
# No instrumentation
-fdsv4l2-profile=off

# Minimal (ops)
-fdsv4l2-profile=ops

# Medium (exercise)
-fdsv4l2-profile=exercise

# Maximal (forensic)
-fdsv4l2-profile=forensic
```

**What DSLLVM does**:
- Scans for functions annotated with `dsv4l2_event(name, severity)`
- Injects calls to `dsv4l2rt_emit()` based on profile level
- Preserves function semantics (no behavior change)

**Example**:
```c
// Source code:
void capture_start(dsv4l2_device_t *dev)
    __attribute__((dsv4l2_event("capture_start", "medium")));

// After DSLLVM instrumentation injection (-fdsv4l2-profile=ops):
void capture_start(dsv4l2_device_t *dev) {
    dsv4l2rt_emit_simple(dev->id, DSV4L2_EVENT_CAPTURE_START,
                         DSV4L2_SEV_MEDIUM, 0);
    // ... original function body
}
```

---

### 4. Static Metadata Emission

**Flag**: `-fdsv4l2-metadata`

**What it does**:
- Emits ELF sections with device/role/layer info
- No runtime overhead
- Consumed by L8 advisor, MEMSHADOW, deployment tools

**Example metadata**:
```
.dsv4l2_sensors:
  - device: "/dev/video0"
    role: "iris_scanner"
    layer: "L3"
    classification: "SECRET_BIOMETRIC"
    functions: ["dsv4l2_capture_iris", "dsv4l2_enter_iris_mode"]
```

---

## Building with DSLLVM

### Prerequisites

```bash
# Standard build tools
apt-get install build-essential cmake ninja-build python3 git libssl-dev

# Clone DSLLVM
git clone https://github.com/SWORDIntel/DSLLVM
cd DSLLVM
```

### Build DSLLVM

```bash
cmake -G Ninja -S llvm -B build \
  -DCMAKE_BUILD_TYPE=Release \
  -DLLVM_ENABLE_PROJECTS="clang;lld" \
  -DLLVM_ENABLE_DSMIL=ON \
  -DLLVM_TARGETS_TO_BUILD="X86;AArch64"

ninja -C build

# Install (optional)
sudo ninja -C build install
```

### Set Up as Default Compiler

```bash
export CC=/path/to/DSLLVM/build/bin/clang
export CXX=/path/to/DSLLVM/build/bin/clang++
export LD=/path/to/DSLLVM/build/bin/ld.lld
```

---

## Compiling DSV4L2 Code

### Basic Compilation (No Instrumentation)

```bash
dsclang -O2 -I include -c my_sensor.c -o my_sensor.o
```

**Result**: Standard object file, attributes ignored

---

### With DSLLVM Passes (Security Enforcement)

```bash
dsclang -O2 \
  -fplugin=libDSLLVM.so \
  -fplugin-arg-dsllvm-pass-config=config/dsllvm_dsv4l2_passes.yaml \
  -I include \
  -c my_sensor.c -o my_sensor.o
```

**Result**: Secret flow, TEMPEST policy, constant-time checks enforced

---

### With Instrumentation (Telemetry)

```bash
dsclang -O2 \
  -fplugin=libDSLLVM.so \
  -fplugin-arg-dsllvm-pass-config=config/dsllvm_dsv4l2_passes.yaml \
  -fdsv4l2-profile=ops \
  -mdsv4l2-mission=operation_name \
  -I include \
  -c my_sensor.c -o my_sensor.o

# Link with runtime
dsclang my_sensor.o -ldsv4l2rt -lv4l2 -o my_sensor
```

**Result**: Enforcement + runtime telemetry injected

---

### Metadata-Only (No Runtime)

```bash
dsclang -O2 \
  -fplugin=libDSLLVM.so \
  -fplugin-arg-dsllvm-pass-config=config/dsllvm_dsv4l2_passes.yaml \
  -fdsv4l2-metadata \
  -I include \
  -c my_sensor.c -o my_sensor.o
```

**Result**: Static metadata in ELF, no runtime calls

---

## DSLLVM Repository Structure

```
DSLLVM/
├── llvm/              # Core LLVM
├── clang/             # C/C++ frontend
├── lld/               # Linker
├── lldb/              # Debugger
├── dsmil/             # DSMIL implementation
│   ├── lib/           # Pass implementations
│   ├── include/       # Headers
│   └── docs/
│       ├── DSLLVM-DESIGN.md
│       └── MISSION-PROFILES-GUIDE.md
├── tpm2_compat/       # TPM2 crypto compatibility
└── ...
```

---

## Key Documentation in DSLLVM Repo

| File | Content |
|------|---------|
| `DSLLVM-BUILD-GUIDE.md` | Compiler configuration |
| `dsmil/docs/DSLLVM-DESIGN.md` | DSMIL architecture |
| `dsmil/docs/MISSION-PROFILES-GUIDE.md` | Mission profiles |
| `tpm2_compat/README.md` | 88 cryptographic algorithms |

---

## Language Support

**Composition**:
- LLVM IR: 40.6%
- C++: 30.8%
- C: 13.1%
- Assembly: 9.8%
- Python: 1.7%
- MLIR: 1.4%

**What you can compile**:
- C (primary for DSV4L2)
- C++
- Rust (via LLVM backend)
- Swift, Kotlin/Native, etc.

---

## Current Status

**Core compiler**: Production-ready
- Drop-in replacement for standard clang
- Passes upstream LLVM test suite
- Used in production defense systems

**DSMIL/AI/quantum hooks**: Experimental
- API subject to change
- Active development
- Feedback-driven evolution

**Downstream runtime integration**: Outside repo scope
- DSV4L2 provides `libdsv4l2rt`
- SHRINK provides `libshrinkrt`
- Each layer implements own runtime

---

## Troubleshooting

### Build fails: "unknown attribute 'dsmil_secret'"

**Cause**: Not using DSLLVM or plugin not loaded

**Fix**: Ensure `-fplugin=libDSLLVM.so` and DSMIL enabled in build

---

### Warning: "DSMIL pass not found"

**Cause**: Pass config file not found or malformed

**Fix**: Check `-fplugin-arg-dsllvm-pass-config=<path>`

---

### Error: "Secret flow violation at line X"

**Cause**: DSLLVM detected secret data flowing to forbidden sink

**Fix**: Remove forbidden operation or use allowed sink

---

## Advantages of DSLLVM Approach

1. **Compile-time enforcement**: Catch violations before runtime
2. **Zero runtime overhead**: Checks happen at build time
3. **Gradual adoption**: Works with existing code
4. **Standard fallback**: Builds on regular compilers (attributes ignored)
5. **IR-level analysis**: More powerful than source-level linting
6. **Automatic instrumentation**: No manual probe insertion

---

## Relationship to DSMIL

**DSMIL** = Defense System Multi-layer Integration Layer (8 layers, L0-L8)

**DSLLVM** = Compiler that emits DSMIL-aware code

**DSV4L2** = L3 sensor library built with DSLLVM

```
L8: SPECTRA (AI orchestration)
L7: Quantum/accelerator offload
L6: Data fusion
L5: Policy/advisor
L4: Application logic
L3: Sensors/devices ← DSV4L2 lives here
L2: HAL
L1: Drivers
L0: Hardware
```

DSLLVM helps enforce:
- Layer boundaries (L3 code can't call L5 directly)
- Clearance requirements (SECRET data doesn't leak to UNCLASSIFIED)
- Sensor routing (iris scanner events → biometric pipeline)

---

## References

- **DSLLVM Repo**: https://github.com/SWORDIntel/DSLLVM
- **LLVM Project**: https://llvm.org
- **CNSA 2.0**: https://media.defense.gov/2022/Sep/07/2003071834/-1/-1/0/CSA_CNSA_2.0_ALGORITHMS_.PDF
- **TPM 2.0**: https://trustedcomputinggroup.org/resource/tpm-library-specification/

---

**For DSV4L2 development, you need**:
1. DSLLVM compiler installed
2. Pass config file (`config/dsllvm_dsv4l2_passes.yaml`)
3. Headers with annotations (`include/dsv4l2_annotations.h`)
4. Runtime library (`libdsv4l2rt`)

**All provided in this bundle.**
