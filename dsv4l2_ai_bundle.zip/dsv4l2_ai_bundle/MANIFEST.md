# DSV4L2 AI Bundle - File Manifest

**Complete listing of all files in this bundle with descriptions**

Version: 1.0
Generated: 2025-11-25

---

## Root Level

| File | Description | Priority |
|------|-------------|----------|
| `README.md` | Bundle overview and navigation guide | **START HERE** |
| `QUICK_START.md` | Fast-track guide for common tasks | **HIGH** |
| `MANIFEST.md` | This file - complete file listing | Reference |

---

## docs/ - Documentation

### Core Documentation

| File | Description | AI Priority | Lines |
|------|-------------|-------------|-------|
| `00_IMPLEMENTATION_PLAN.md` | Complete implementation breakdown with task estimates | **CRITICAL** | 600+ |
| `01_DESIGN.md` | Full architecture and design specification | **CRITICAL** | 450+ |
| `02_DSLLVM_CONTEXT.md` | DSLLVM compiler overview and usage | **HIGH** | 550+ |

### Purpose by File

**00_IMPLEMENTATION_PLAN.md**:
- 8-phase implementation roadmap
- File-by-file breakdown with complexity ratings
- Estimated lines of code per component
- Critical path analysis
- 10-15 day total timeline
- Detailed function signatures for each component

**01_DESIGN.md**:
- Architecture overview (7 components)
- DSLLVM annotations & types
- Security enforcement (secret flow, TEMPEST, constant-time)
- Role-aware profiles specification
- Metadata & fusion sensor support
- Instrumentation & runtime telemetry
- AI/quantum hooks
- Build instructions
- Complete file structure

**02_DSLLVM_CONTEXT.md**:
- What is DSLLVM (compiler overview)
- How DSV4L2 uses DSLLVM
- Custom pass explanations (secret_flow, tempest_policy, constant_time)
- Build DSLLVM from source
- Compilation examples
- Troubleshooting guide
- DSMIL integration context

---

## headers/ - C Header Files

| File | Description | LOC | Critical Functions/Types |
|------|-------------|-----|--------------------------|
| `dsv4l2_annotations.h` | DSLLVM attribute macros & base types | 86 | All annotation macros, `dsv4l2_frame_t`, `dsv4l2_meta_t`, `dsv4l2_tempest_state_t` |
| `dsv4l2_policy.h` | Policy API declarations (TEMPEST, capture) | 50 | `dsv4l2_get_tempest_state()`, `dsv4l2_capture_frame()`, `dsv4l2_capture_iris()` |
| `dsv4l2rt.h` | Runtime instrumentation API | 230 | `dsv4l2rt_init()`, `dsv4l2rt_emit()`, event types, sink configuration |

### Header Details

**dsv4l2_annotations.h**:
- Security attributes: `DSMIL_SECRET`, `DSMIL_TEMPEST`, `DSMIL_SECRET_REGION`
- Instrumentation attributes: `DSV4L2_SENSOR`, `DSV4L2_EVENT`, `DSV4L2_TEMPEST_CONTROL`
- Base types: frames, metadata, TEMPEST states, device handles
- **Include first** in all DSV4L2 code

**dsv4l2_policy.h**:
- TEMPEST query/transition functions
- Capture function declarations (frame, iris, fused)
- Policy check API
- **Implement these** in Phase 2

**dsv4l2rt.h**:
- Event types (20+ events defined)
- Runtime configuration (profiles, sinks, TPM signing)
- Emission API (simple and full events)
- Statistics and introspection
- **Implement** in Phase 6

---

## config/ - DSLLVM Configuration

| File | Description | Lines | Pass Count |
|------|-------------|-------|------------|
| `dsllvm_dsv4l2_passes.yaml` | Complete DSLLVM pass configuration | 124 | 3 passes |

### Pass Configuration Details

**Passes defined**:
1. `dsmil.secret_flow` (lines 23-66)
   - Tracks biometric/secret data
   - 8 forbidden APIs (printf, send, write, etc.)
   - 3 allowed sinks (encrypted storage, secure network, declassify)
   - SARIF output for violations

2. `dsmil.tempest_policy` (lines 68-97)
   - TEMPEST state tracking
   - Mandatory policy checks before capture
   - Forbidden state enforcement (LOCKDOWN)
   - Transition authorization

3. `dsmil.constant_time` (lines 99-123)
   - Constant-time enforcement in secret regions
   - Forbids secret-dependent branches/switches/indexing
   - Applied to iris capture and preprocessing

**Usage**: `-fplugin-arg-dsllvm-pass-config=config/dsllvm_dsv4l2_passes.yaml`

---

## examples/ - Code Examples

| File | Description | Lines | Functions |
|------|-------------|-------|-----------|
| `instrumented_capture_example.c` | Before/after instrumentation examples | 340 | 6 example functions |
| `profile_iris_scanner.yaml` | Complete iris scanner device profile | 230 | N/A (config) |

### Example Code Details

**instrumented_capture_example.c**:
- `capture_frame_plain()` - Plain v4l2 (no DSLLVM)
- `dsv4l2_capture_frame_instrumented()` - With TEMPEST checks & events
- `dsv4l2_capture_iris_instrumented()` - Secret region, constant-time
- `dsv4l2_fused_capture_instrumented()` - Quantum candidate
- `dsv4l2_set_tempest_state_instrumented()` - State transitions
- **Study this file** to understand annotation patterns

**profile_iris_scanner.yaml**:
- Complete device profile example
- USB VID:PID, role, classification
- Video format configuration (1280x720@60fps)
- TEMPEST control mapping
- Camera controls (exposure, focus, etc.)
- Policy enforcement rules
- Telemetry configuration
- Feature extraction definitions
- **Use as template** for other devices

---

## reference/ - Reference Materials

| File | Description | Lines | Content Type |
|------|-------------|-------|--------------|
| `COMPILER_FLAGS.md` | Complete DSLLVM flag reference | 450 | Documentation |
| `ORIGINAL_BUNDLE_README.md` | Original zip bundle documentation | 44 | Historical |
| `V4L2CTL_ORIGINAL_README.rst` | Original v4l2ctl project readme | 115 | Historical |

### Reference Details

**COMPILER_FLAGS.md**:
- Core DSLLVM flags (`-fplugin`, `-fplugin-arg-dsllvm-pass-config`)
- DSV4L2 flags (`-fdsv4l2-profile`, `-mdsv4l2-mission`)
- Flag combinations (dev/production/forensic)
- Build system integration (Make, CMake)
- Debugging flags
- Quick reference table
- Common errors and solutions

**ORIGINAL_BUNDLE_README.md**:
- Original bundle from `dsv4l2_dsllvm_bundle.zip`
- DSLLVM integration guide
- Pass configuration overview
- Build invocation example

**V4L2CTL_ORIGINAL_README.rst**:
- Original v4l2ctl Python library readme
- Installation instructions
- Basic usage examples
- Historical context

---

## File Statistics

### Total Files: 13

**By category**:
- Documentation: 6 files (~2,000 lines)
- Headers: 3 files (~370 lines)
- Configuration: 1 file (~130 lines)
- Examples: 2 files (~570 lines)
- Reference: 3 files (~610 lines)

**Total content**: ~3,680 lines (excluding original readmes)

### Lines of Code Distribution

| Category | Lines | Percentage |
|----------|-------|------------|
| Documentation | 2,000 | 54% |
| Reference | 610 | 17% |
| Examples | 570 | 15% |
| Headers | 370 | 10% |
| Configuration | 130 | 4% |

---

## Reading Order for AI Assistants

### 1. First Pass (Orientation) - 30 minutes

1. `README.md` - Bundle overview
2. `QUICK_START.md` - Core concepts
3. `docs/01_DESIGN.md` Section 0-2 - Purpose and architecture

### 2. Second Pass (Technical Deep Dive) - 2 hours

1. `docs/02_DSLLVM_CONTEXT.md` - Compiler understanding
2. `headers/dsv4l2_annotations.h` - Annotation reference
3. `config/dsllvm_dsv4l2_passes.yaml` - Enforcement rules
4. `examples/instrumented_capture_example.c` - Code patterns

### 3. Third Pass (Implementation) - As needed

1. `docs/00_IMPLEMENTATION_PLAN.md` - Task breakdown
2. `reference/COMPILER_FLAGS.md` - Build reference
3. `examples/profile_iris_scanner.yaml` - Profile template
4. `docs/01_DESIGN.md` Sections 3-13 - Complete spec

---

## Usage Patterns by Role

### For AI Code Assistants

**Primary references**:
- `docs/00_IMPLEMENTATION_PLAN.md` - What to build
- `examples/instrumented_capture_example.c` - How to build it
- `headers/*.h` - API contracts

**Implementation order**:
- Start with Phase 2.1 (device.c)
- Reference example code for patterns
- Use headers for function signatures

### For Security Reviewers

**Primary references**:
- `config/dsllvm_dsv4l2_passes.yaml` - Enforcement rules
- `docs/02_DSLLVM_CONTEXT.md` - How enforcement works
- `examples/profile_iris_scanner.yaml` - Policy configuration

**Focus areas**:
- Secret flow tracking (prevents leaks)
- TEMPEST enforcement (mandatory checks)
- Constant-time guarantees (timing safety)

### For System Integrators

**Primary references**:
- `QUICK_START.md` - Fast orientation
- `reference/COMPILER_FLAGS.md` - Build configuration
- `examples/profile_iris_scanner.yaml` - Device configuration

**Integration checklist**:
- Install DSLLVM compiler
- Configure device profiles
- Set up telemetry sinks (Redis/SQLite)
- Deploy with appropriate `-fdsv4l2-profile` level

---

## Dependencies Between Files

### Build-Time Dependencies

```
dsv4l2_annotations.h
    ↓
dsv4l2_policy.h (includes annotations)
    ↓
instrumented_capture_example.c (includes both)
    ↓
dsllvm_dsv4l2_passes.yaml (references annotations)
```

### Conceptual Dependencies

```
DESIGN.md (architecture)
    ↓
IMPLEMENTATION_PLAN.md (tasks)
    ↓
instrumented_capture_example.c (code patterns)
    ↓
(implement actual library)
```

### Documentation Flow

```
README.md (start here)
    ↓
QUICK_START.md (core concepts)
    ↓
DESIGN.md OR IMPLEMENTATION_PLAN.md (depending on goal)
    ↓
DSLLVM_CONTEXT.md (compiler details)
    ↓
COMPILER_FLAGS.md (build reference)
```

---

## Update History

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | 2025-11-25 | Initial bundle creation |

---

## Checksums (for verification)

Generated with: `sha256sum *`

```
(Checksums would be generated at bundle creation time)
```

---

## Bundle Size

**Uncompressed**: ~150 KB
**Compressed (ZIP)**: ~35 KB (estimated)

---

**This manifest provides complete navigation for the DSV4L2 AI documentation bundle.**
