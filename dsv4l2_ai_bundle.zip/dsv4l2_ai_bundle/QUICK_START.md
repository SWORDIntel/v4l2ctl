# DSV4L2 Quick Start Guide

**Fast track to understanding and using DSV4L2**

---

## 5-Minute Overview

### What is DSV4L2?

DSV4L2 transforms a simple v4l2 camera library into a **security-aware, policy-enforced, telemetry-enabled sensor node** in the DSMIL fabric.

**Key capabilities:**
- 🔒 **Secret flow tracking** - Biometric data can't leak
- 🛡️ **TEMPEST enforcement** - Electromagnetic security built-in
- 📊 **Runtime telemetry** - Every capture, error, state change logged
- ⚡ **Quantum hooks** - Hot paths tagged for L7/L8 offload
- 🎯 **Role-aware** - Iris scanner ≠ webcam ≠ IR sensor

### How it Works

1. **Compile-time**: DSLLVM enforces security policies at IR level
2. **Runtime**: Events flow into DSMIL fabric (Redis/SHRINK/MEMSHADOW)
3. **Deploy-time**: Profiles configure devices by role/classification

---

## Common Tasks

### Task 1: Understand the Architecture

**Read first**: `docs/01_DESIGN.md` Section 1 (Architecture Overview)

**Key concepts:**
- **Annotations** (`headers/dsv4l2_annotations.h`): Mark code with security metadata
- **Passes** (`config/dsllvm_dsv4l2_passes.yaml`): Enforce policies at compile time
- **Runtime** (`headers/dsv4l2rt.h`): Collect and emit telemetry
- **Profiles** (TBD): Configure devices by role

**Time**: 10 minutes

---

### Task 2: See Example Code

**File**: `examples/instrumented_capture_example.c`

**What to look for:**
- **Before/After comparison** (plain v4l2 vs DSLLVM-instrumented)
- **TEMPEST checks** before capture
- **Event emission** at key points
- **Annotation usage** (`DSV4L2_SENSOR`, `DSMIL_SECRET`, etc.)

**Key function**: `dsv4l2_capture_frame_instrumented()` (line ~50)

**Time**: 15 minutes

---

### Task 3: Understand TEMPEST Enforcement

**The problem**: Electromagnetic emissions from sensors can leak data

**The solution**: 4-state machine enforced at compile-time

```c
typedef enum {
    DSV4L2_TEMPEST_DISABLED = 0,  // Normal operation
    DSV4L2_TEMPEST_LOW      = 1,  // Basic shielding
    DSV4L2_TEMPEST_HIGH     = 2,  // Enhanced protection
    DSV4L2_TEMPEST_LOCKDOWN = 3,  // No capture allowed
} dsv4l2_tempest_state_t;
```

**DSLLVM enforces**:
- Every `dsv4l2_capture_*()` function **must** call `dsv4l2_get_tempest_state()`
- Every capture **must** call `dsv4l2_policy_check()` before returning data
- If state is `LOCKDOWN`, capture is rejected at runtime
- Missing checks = build failure

**See**: `examples/instrumented_capture_example.c` line ~65

**Time**: 5 minutes

---

### Task 4: Understand Secret Flow Tracking

**The problem**: Biometric/sensitive data can leak via printf, network, unencrypted storage

**The solution**: DSLLVM tracks `dsmil_secret` types across IR

```c
typedef struct {
    uint8_t *data;
    size_t   len;
} dsv4l2_frame_t __attribute__((dsmil_secret("biometric_frame")));
```

**DSLLVM enforces**:
- **Forbidden**: `printf()`, `fprintf()`, `send()`, `write()`, `syslog()` with secret data
- **Allowed sinks only**:
  - `dsv4l2_store_encrypted()` - encrypted storage
  - `dsv4l2_send_over_mtls()` - secure network
  - `dsmil_declassify()` - explicit declassification

**See**: `config/dsllvm_dsv4l2_passes.yaml` lines 51-66

**Time**: 10 minutes

---

### Task 5: Understand Instrumentation Profiles

**The problem**: Different deployments need different telemetry verbosity

**The solution**: Compiler flag controls instrumentation level

```bash
# No instrumentation (production)
-fdsv4l2-profile=off

# Minimal counters (ops)
-fdsv4l2-profile=ops

# Per-stream stats (exercise/testing)
-fdsv4l2-profile=exercise

# Full audit trail (forensic/incident response)
-fdsv4l2-profile=forensic
```

**What changes**:
- `off`: No runtime calls injected
- `ops`: Frame counts, errors, TEMPEST transitions only
- `exercise`: Add frame stats, metadata sampling
- `forensic`: Every event, full context, TPM-signed chunks

**See**: `headers/dsv4l2rt.h` lines 65-75

**Time**: 5 minutes

---

## Implementation Quick Start

### If You're Implementing DSV4L2

1. **Read**: `docs/00_IMPLEMENTATION_PLAN.md`
2. **Start with**: Phase 2.1 (Device Management)
3. **Next**: Phase 2.5 (TEMPEST State)
4. **Then**: Phase 2.4 (Capture)

**Critical path**:
```
device.c → tempest.c → capture.c → runtime stub → working demo
```

**Estimated time to first demo**: 2-3 days

---

### If You're Using DSV4L2

1. **Install**: DSLLVM compiler (see `docs/02_DSLLVM_CONTEXT.md`)
2. **Write**: Code using headers in `headers/`
3. **Annotate**: Functions with `DSV4L2_SENSOR`, types with `DSMIL_SECRET`
4. **Compile**: With `-fplugin=libDSLLVM.so` and pass config
5. **Link**: With `libdsv4l2rt` for runtime telemetry

**Example**:
```bash
dsclang -O2 \
  -fplugin=libDSLLVM.so \
  -fplugin-arg-dsllvm-pass-config=config/dsllvm_dsv4l2_passes.yaml \
  -fdsv4l2-profile=ops \
  -I headers \
  my_camera_app.c -o my_camera_app
```

---

## Troubleshooting

### Build fails with "tempest check missing"

**Cause**: DSLLVM detected a capture function without TEMPEST state check

**Fix**: Add this before capture:
```c
dsv4l2_tempest_state_t state = dsv4l2_get_tempest_state(dev);
if (dsv4l2_policy_check(state, "my_function") != 0) {
    return -EPERM;
}
```

---

### Build fails with "secret flow violation"

**Cause**: DSLLVM detected secret data flowing to forbidden sink (printf, etc.)

**Fix**: Remove the forbidden operation or use allowed sink:
```c
// BAD:
printf("Frame: %p\n", biometric_frame->data);

// GOOD:
dsv4l2_store_encrypted(biometric_frame);
```

---

### Runtime events not appearing

**Cause**: Instrumentation profile is `off` or runtime not initialized

**Fix**:
1. Check compile flag: `-fdsv4l2-profile=ops` or higher
2. Call `dsv4l2rt_init()` at startup
3. Check sink configuration (Redis, SQLite, etc.)

---

## Next Steps

**For deeper understanding:**
1. Read `docs/01_DESIGN.md` (complete architecture)
2. Read `docs/02_DSLLVM_CONTEXT.md` (compiler internals)
3. Study `config/dsllvm_dsv4l2_passes.yaml` (enforcement rules)

**For implementation:**
1. Read `docs/00_IMPLEMENTATION_PLAN.md` (task breakdown)
2. Set up build environment
3. Start with Phase 2 (Core Library)

**For integration:**
1. Read `docs/05_INTEGRATION_GUIDE.md` (DSMIL fabric)
2. Configure sinks (Redis/SQLite)
3. Set up profiles for your devices

---

## Cheat Sheet

### Key Files

| File | Purpose | When to Read |
|------|---------|--------------|
| `QUICK_START.md` | This file | First |
| `docs/00_IMPLEMENTATION_PLAN.md` | Task breakdown | Implementing |
| `docs/01_DESIGN.md` | Full architecture | Understanding |
| `examples/instrumented_capture_example.c` | Code patterns | Coding |
| `headers/dsv4l2_annotations.h` | Attribute reference | Annotating |
| `config/dsllvm_dsv4l2_passes.yaml` | Policy rules | Debugging |

### Key Annotations

```c
// Device/function role
DSV4L2_SENSOR("iris_scanner", "L3", "SECRET_BIOMETRIC")

// Secret data type
DSMIL_SECRET("biometric_frame")

// Secret code region (constant-time enforced)
DSMIL_SECRET_REGION

// Requires TEMPEST check
DSMIL_REQUIRES_TEMPEST_CHECK

// TEMPEST state query/transition
DSMIL_TEMPEST_QUERY
DSMIL_TEMPEST_TRANSITION

// Quantum optimization candidate
DSMIL_QUANTUM_CANDIDATE("fused_capture")
```

### Key Runtime Calls

```c
// Initialize runtime
dsv4l2rt_init(&config);

// Emit simple event
dsv4l2rt_emit_simple(dev_id, DSV4L2_EVENT_CAPTURE_START,
                     DSV4L2_SEV_INFO, 0);

// Emit full event
dsv4l2rt_emit(&event);

// Flush to sinks
dsv4l2rt_flush();
```

---

**Total reading time**: ~1 hour for complete understanding
**Time to first working code**: 2-3 days
